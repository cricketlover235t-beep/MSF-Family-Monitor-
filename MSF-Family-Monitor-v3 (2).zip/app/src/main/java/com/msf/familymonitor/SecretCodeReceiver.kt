package com.msf.familymonitor

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Dialing *#*#12340#*#*, *#*#56780#*#* or *#*#99110#*#* on this phone's own dialer
 * fires this receiver, which opens the app directly even while its launcher icon is hidden.
 * (Android requires these codes to be fixed in the manifest; they cannot be changed at runtime.)
 */
class SecretCodeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val open = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        context.startActivity(open)
    }
}
