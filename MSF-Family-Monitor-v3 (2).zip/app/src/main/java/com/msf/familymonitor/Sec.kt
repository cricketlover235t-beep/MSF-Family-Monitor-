package com.msf.familymonitor

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import java.io.File

object Sec {
    var gOk = false
    var aOk = false
    fun sp(c: Context) = c.getSharedPreferences("msf", Context.MODE_PRIVATE)

    fun input(a: Context, title: String, cb: (String) -> Unit) {
        val et = EditText(a).apply { inputType = 0x12; hint = "PIN" }
        AlertDialog.Builder(a).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> cb(et.text.toString()) }.setNegativeButton("Cancel", null).show()
    }

    private fun gate(a: Activity, title: String, check: (String) -> Boolean, onCancel: () -> Unit) {
        val et = EditText(a).apply { inputType = 0x12; hint = "PIN" }
        AlertDialog.Builder(a).setTitle(title).setView(et).setCancelable(false)
            .setPositiveButton("OK") { _, _ ->
                if (!check(et.text.toString())) { Toast.makeText(a, "Wrong or invalid PIN", Toast.LENGTH_SHORT).show(); gate(a, title, check, onCancel) }
            }.setNegativeButton("Cancel") { _, _ -> onCancel() }.show()
    }

    fun galleryGuard(a: Activity) {
        val s = sp(a)
        if (!s.getBoolean("secure", true) || gOk) return
        val pin = s.getString("pin", null)
        if (pin == null) gate(a, "Set a new PIN (min 4 digits)", { p -> if (p.length >= 4) { s.edit().putString("pin", p).apply(); gOk = true; true } else false }) { a.finish() }
        else gate(a, "Enter PIN", { p -> if (p == pin) { gOk = true; true } else false }) { a.finish() }
    }

    fun appGuard(a: Activity) {
        val ppw = sp(a).getString("ppw", null)
        if (ppw == null || aOk) return
        gate(a, "Parental Password", { p -> if (p == ppw) { aOk = true; true } else false }) { a.finish() }
    }
}

/** Hides/shows the home-screen & app-drawer icon. The app keeps running either way —
 *  Android's own Settings > Apps list still lists every installed app regardless of this,
 *  there is no way around that on a normal, non-rooted phone. */
object HideIcon {
    private fun alias(c: Context) = ComponentName(c.packageName, "com.msf.familymonitor.LauncherAlias")
    fun isHidden(c: Context) = c.packageManager.getComponentEnabledSetting(alias(c)) == PackageManager.COMPONENT_ENABLED_STATE_DISABLED
    fun setHidden(c: Context, hide: Boolean) {
        c.packageManager.setComponentEnabledSetting(alias(c),
            if (hide) PackageManager.COMPONENT_ENABLED_STATE_DISABLED else PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP)
    }
}

/** Per-brand battery/autostart screen, since MIUI, ColorOS, FuntouchOS, EMUI etc. each kill
 *  background apps their own way and the standard Android settings screen doesn't reach that. */
object Brand {
    data class Entry(val label: String, val action: () -> Intent)
    fun list(pkg: String): List<Entry> = listOf(
        Entry("Xiaomi / Redmi / POCO (MIUI)") { Intent().setClassName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity") },
        Entry("Vivo (FuntouchOS)") { Intent().setClassName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity") },
        Entry("Oppo / Realme (ColorOS)") { Intent().setClassName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity") },
        Entry("OnePlus") { Intent().setClassName("com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity") },
        Entry("Huawei / Honor (EMUI)") { Intent().setClassName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity") },
        Entry("Samsung / Other (battery settings)") { Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$pkg")) }
    )
}

object Cleanup {
    fun dir(c: Context) = File(c.getExternalFilesDir(null), "recordings").also { it.mkdirs() }
    fun run(c: Context) { val d = Sec.sp(c).getInt("cleanup", 0); if (d > 0) delete(c, d) }
    fun delete(c: Context, days: Int): Int {
        val cut = System.currentTimeMillis() - days * 86400000L
        return dir(c).listFiles()?.filter { it.lastModified() < cut }?.count { it.delete() } ?: 0
    }
}

object Monitor {
    const val REQ = 100
    fun toggle(a: Activity) {
        if (RecordService.running) { a.stopService(Intent(a, RecordService::class.java)); RecordService.running = false } else request(a)
    }
    @Suppress("DEPRECATION")
    fun request(a: Activity) {
        val m = a.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        a.startActivityForResult(m.createScreenCaptureIntent(), REQ)
    }
    fun onResult(a: Activity, req: Int, res: Int, d: Intent?) {
        if (req != REQ) return
        if (res == Activity.RESULT_OK && d != null) {
            a.startForegroundService(Intent(a, RecordService::class.java).putExtra("data", d)); RecordService.running = true
        } else Toast.makeText(a, "Permission denied", Toast.LENGTH_SHORT).show()
    }
}
