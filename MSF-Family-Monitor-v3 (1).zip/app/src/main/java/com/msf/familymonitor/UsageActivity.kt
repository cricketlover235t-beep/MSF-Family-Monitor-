package com.msf.familymonitor

import android.app.AppOpsManager
import android.app.DatePickerDialog
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class UsageActivity : AppCompatActivity() {
    data class Use(val pkg: String, val name: String, val ms: Long, val icon: Drawable?, val cat: Int, val last: Long)
    private var tab = 0
    private var day: Calendar = Calendar.getInstance()
    private val colors = intArrayOf(0xFF2979FF.toInt(), 0xFFFF6B8A.toInt(), 0xFF22C55E.toInt(), 0xFFF59E0B.toInt())
    private val cats = arrayOf("Social Media", "Games", "YouTube", "Others")
    private val social = listOf("instagram", "facebook", "whatsapp", "snapchat", "twitter", "telegram", "tiktok", "musically", "pinterest", "linkedin", "reddit", "discord")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_usage)
        findViewById<TextView>(R.id.hdrBtn).apply { text = "⚙"; setOnClickListener { startActivity(Intent(context, SettingsActivity::class.java)) } }
        Nav.setup(this, 2)
        listOf(R.id.uTab0, R.id.uTab1, R.id.uTab2, R.id.uTab3).forEachIndexed { i, id -> findViewById<View>(id).setOnClickListener { tab = i; render() } }
        findViewById<View>(R.id.dateBtn).setOnClickListener {
            DatePickerDialog(this, { _, y, m, d -> day.set(y, m, d); render() }, day.get(Calendar.YEAR), day.get(Calendar.MONTH), day.get(Calendar.DAY_OF_MONTH)).apply { datePicker.maxDate = System.currentTimeMillis() }.show()
        }
        findViewById<View>(R.id.refreshBtn).setOnClickListener { render(); Toast.makeText(this, "Refreshed", Toast.LENGTH_SHORT).show() }
    }

    override fun onResume() { super.onResume(); render() }

    private fun hasAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun fmt(ms: Long) = "${ms / 3600000}h ${ms / 60000 % 60}m"

    private fun range(c: Calendar): Pair<Long, Long> {
        val s = c.clone() as Calendar
        s.set(Calendar.HOUR_OF_DAY, 0); s.set(Calendar.MINUTE, 0); s.set(Calendar.SECOND, 0); s.set(Calendar.MILLISECOND, 0)
        return Pair(s.timeInMillis, minOf(s.timeInMillis + 86400000L - 1, System.currentTimeMillis()))
    }

    @Suppress("DEPRECATION")
    private fun query(c: Calendar): List<Use> {
        val (s, e) = range(c)
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val pm = packageManager
        return usm.queryAndAggregateUsageStats(s, e).values.filter { it.totalTimeInForeground > 60000 && it.packageName != packageName }.mapNotNull {
            try {
                val ai = pm.getApplicationInfo(it.packageName, 0)
                val game = (android.os.Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                val cat = when {
                    it.packageName.startsWith("com.google.android.youtube") -> 2
                    game -> 1
                    social.any { k -> it.packageName.contains(k) } -> 0
                    else -> 3
                }
                Use(it.packageName, pm.getApplicationLabel(ai).toString(), it.totalTimeInForeground, pm.getApplicationIcon(ai), cat, it.lastTimeUsed)
            } catch (e: Exception) { null }
        }.sortedByDescending { it.ms }
    }

    private fun render() {
        listOf(R.id.uTab0, R.id.uTab1, R.id.uTab2, R.id.uTab3).forEachIndexed { i, id ->
            val t = findViewById<TextView>(id)
            t.setBackgroundResource(if (i == tab) R.drawable.bg_tab_sel else R.drawable.bg_tab)
            t.setTextColor(if (i == tab) 0xFFFFFFFF.toInt() else 0xFF0A1F6B.toInt())
        }
        findViewById<TextView>(R.id.dateBtn).text = SimpleDateFormat("MMM dd, yyyy  ▾", Locale.US).format(day.time)
        val box = findViewById<LinearLayout>(R.id.content); box.removeAllViews()
        if (!hasAccess()) {
            val t = TextView(this).apply { text = "Usage access is needed to show this report.\nTap here, then enable MSF Family Monitor."; textSize = 15f; setPadding(30, 30, 30, 30); setBackgroundResource(R.drawable.bg_note_orange); setTextColor(0xFF333333.toInt())
                setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } }
            box.addView(t); return
        }
        when (tab) {
            0 -> screenTime(box)
            1 -> appsReport(box)
            2 -> box.addView(TextView(this).apply { text = "🌐 Web History\n\nAndroid does not allow apps to read other apps' browsing history, so this can't be shown. See the Apps Report tab to check how much time is spent in browsers like Chrome."; textSize = 14f; setPadding(30, 30, 30, 30); setBackgroundResource(R.drawable.bg_row); setTextColor(0xFF333333.toInt()) })
            3 -> daily(box)
        }
    }

    private fun addRows(host: LinearLayout, items: List<Use>, total: Long) {
        val inf = LayoutInflater.from(this)
        items.forEach { u ->
            val v = inf.inflate(R.layout.item_usage, host, false)
            v.findViewById<ImageView>(R.id.uIcon).setImageDrawable(u.icon)
            v.findViewById<TextView>(R.id.uName).text = u.name
            v.findViewById<TextView>(R.id.uTime).text = fmt(u.ms) + "   "
            val pct = if (total > 0) (u.ms * 100 / total).toInt() else 0
            v.findViewById<TextView>(R.id.uPct).text = "$pct%"
            v.findViewById<ProgressBar>(R.id.uBar).apply { progress = pct; progressTintList = android.content.res.ColorStateList.valueOf(colors[u.cat]) }
            host.addView(v)
        }
    }

    private fun screenTime(box: LinearLayout) {
        val v = LayoutInflater.from(this).inflate(R.layout.view_screen_time, box, false); box.addView(v)
        val data = query(day); val total = data.sumOf { it.ms }
        val byCat = LongArray(4); data.forEach { byCat[it.cat] += it.ms }
        v.findViewById<DonutView>(R.id.donut).set(byCat.map { it.toFloat() }.toFloatArray(), colors, fmt(total))
        val lg = v.findViewById<LinearLayout>(R.id.legend)
        for (i in 0..3) lg.addView(TextView(this).apply {
            val pct = if (total > 0) byCat[i] * 100 / total else 0
            text = "●  ${cats[i]}   ${fmt(byCat[i])} ($pct%)"; textSize = 12f; setTextColor(0xFF111111.toInt()); setPadding(0, 6, 0, 6)
            val sp = android.text.SpannableString(text); sp.setSpan(android.text.style.ForegroundColorSpan(colors[i]), 0, 1, 0); text = sp })
        val limit = 4 * 3600000L
        val ok = total <= limit
        v.findViewById<TextView>(R.id.statusIcon).text = if (ok) "✅" else "⚠"
        v.findViewById<TextView>(R.id.statusTitle).text = if (ok) "Screen Time is within normal limits" else "Screen Time is high"
        v.findViewById<TextView>(R.id.statusSub).text = if (ok) "Keep monitoring for better habits." else "Over 4 hours of use. Consider setting limits."
        v.findViewById<View>(R.id.statusCard).setBackgroundResource(if (ok) R.drawable.bg_note_green else R.drawable.bg_note_orange)
        addRows(v.findViewById(R.id.details), data.take(6), total)
        val isToday = SimpleDateFormat("yyyyMMdd", Locale.US).format(day.time) == SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        v.findViewById<TextView>(R.id.totalText).text = (if (isToday) "Total Usage Today: " else "Total Usage: ") + fmt(total)
        val last = data.maxOfOrNull { it.last }
        v.findViewById<TextView>(R.id.lastText).text = "Last Active: " + (if (last != null) SimpleDateFormat("hh:mm a", Locale.US).format(Date(last)) else "—")
    }

    private fun appsReport(box: LinearLayout) {
        val data = query(day)
        val host = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundResource(R.drawable.bg_row); setPadding(10, 10, 10, 10) }
        if (data.isEmpty()) host.addView(TextView(this).apply { text = "No app usage for this date"; setPadding(20, 20, 20, 20) })
        addRows(host, data, data.sumOf { it.ms }); box.addView(host)
    }

    private fun daily(box: LinearLayout) {
        val host = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundResource(R.drawable.bg_row); setPadding(20, 20, 20, 20) }
        host.addView(TextView(this).apply { text = "📅 Last 7 days"; textSize = 17f; setTextColor(0xFF0A1F6B.toInt()); setTypeface(null, android.graphics.Typeface.BOLD) })
        val days = (0..6).map { (Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -it) }) }
        val totals = days.map { c -> query(c).sumOf { it.ms } }
        val mx = (totals.maxOrNull() ?: 1L).coerceAtLeast(1L)
        days.forEachIndexed { i, c ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(0, 14, 0, 4) }
            row.addView(TextView(this).apply { text = SimpleDateFormat("EEE dd MMM", Locale.US).format(c.time); width = 260; textSize = 13f; setTextColor(0xFF111111.toInt()) })
            row.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = (totals[i] * 100 / mx).toInt(); layoutParams = LinearLayout.LayoutParams(0, 14, 1f) })
            row.addView(TextView(this).apply { text = "  " + fmt(totals[i]); textSize = 13f; setTextColor(0xFF111111.toInt()) })
            host.addView(row)
        }
        box.addView(host)
    }
}
