package com.msf.familymonitor

import android.app.DatePickerDialog
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class AppsActivity : AppCompatActivity() {
    data class Row(val pkg: String, val name: String, val cat: String, val ms: Long, val icon: Drawable?)
    private var tab = 0
    private var day: Calendar = Calendar.getInstance()
    private val palette = intArrayOf(0xFFD50000.toInt(), 0xFFFF6B8A.toInt(), 0xFF22C55E.toInt(), 0xFFF59E0B.toInt(), 0xFF2979FF.toInt(), 0xFF8B5CF6.toInt(), 0xFF16A34A.toInt(), 0xFF475569.toInt())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_apps)
        findViewById<TextView>(R.id.hdrBtn).apply { text = "⚙"; setOnClickListener { startActivity(Intent(context, SettingsActivity::class.java)) } }
        Nav.setup(this, 2)
        listOf(R.id.aTab0, R.id.aTab1, R.id.aTab2, R.id.aTab3).forEachIndexed { i, id -> findViewById<View>(id).setOnClickListener { tab = i; render() } }
        findViewById<View>(R.id.dateBtn).setOnClickListener {
            DatePickerDialog(this, { _, y, m, d -> day.set(y, m, d); render() }, day.get(Calendar.YEAR), day.get(Calendar.MONTH), day.get(Calendar.DAY_OF_MONTH)).apply { datePicker.maxDate = System.currentTimeMillis() }.show()
        }
        findViewById<View>(R.id.refreshBtn).setOnClickListener { render(); Toast.makeText(this, "Refreshed", Toast.LENGTH_SHORT).show() }
    }

    override fun onResume() { super.onResume(); render() }

    private fun fmt(ms: Long) = "${ms / 3600000}h ${ms / 60000 % 60}m"

    private fun catLabel(ai: ApplicationInfo, p: String): String {
        if (p.startsWith("com.google.android.youtube")) return "Video & Entertainment"
        if (p.contains("tiktok") || p.contains("musically")) return "Short Videos"
        if (p.contains("chrome") || p.contains("browser") || p.contains("firefox") || p.contains("opera") || p.contains("edge")) return "Web Browser"
        if (p.contains("whatsapp") || p.contains("telegram") || p.contains("messenger") || p.contains("signal")) return "Messaging"
        if (p.contains("facebook") || p.contains("instagram") || p.contains("snapchat") || p.contains("twitter")) return "Social Media"
        @Suppress("DEPRECATION") if ((ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0) return "Games"
        if (Build.VERSION.SDK_INT >= 26) return when (ai.category) {
            ApplicationInfo.CATEGORY_GAME -> "Games"; ApplicationInfo.CATEGORY_VIDEO -> "Video & Entertainment"
            ApplicationInfo.CATEGORY_SOCIAL -> "Social Media"; ApplicationInfo.CATEGORY_AUDIO -> "Music & Audio"
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"; ApplicationInfo.CATEGORY_NEWS -> "News"
            ApplicationInfo.CATEGORY_MAPS -> "Maps & Navigation"; ApplicationInfo.CATEGORY_IMAGE -> "Photos"
            else -> "Others" }
        return "Others"
    }

    private fun render() {
        listOf(R.id.aTab0, R.id.aTab1, R.id.aTab2, R.id.aTab3).forEachIndexed { i, id ->
            val t = findViewById<TextView>(id)
            t.setBackgroundResource(if (i == tab) R.drawable.bg_tab_sel else R.drawable.bg_tab)
            t.setTextColor(if (i == tab) 0xFFFFFFFF.toInt() else 0xFF0A1F6B.toInt())
        }
        findViewById<TextView>(R.id.dateBtn).text = SimpleDateFormat("MMM dd, yyyy  ▾", Locale.US).format(day.time)
        val box = findViewById<LinearLayout>(R.id.content); box.removeAllViews()
        val pm = packageManager
        val s = (day.clone() as Calendar).apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        val e = minOf(s + 86400000L - 1, System.currentTimeMillis())
        val usage = try { (getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager).queryAndAggregateUsageStats(s, e).mapValues { it.value.totalTimeInForeground } } catch (x: Exception) { emptyMap() }
        if (usage.isEmpty()) box.addView(TextView(this).apply {
            text = "To see usage time, tap here and enable Usage access for MSF Family Monitor."; textSize = 13f; setPadding(24, 20, 24, 20); setTextColor(0xFF333333.toInt()); setBackgroundResource(R.drawable.bg_note_orange)
            setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } })
        val launch = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val rows = launch.map { it.activityInfo.packageName }.distinct().filter { it != packageName }.mapNotNull { p ->
            try { val ai = pm.getApplicationInfo(p, 0); Row(p, pm.getApplicationLabel(ai).toString(), catLabel(ai, p), usage[p] ?: 0L, pm.getApplicationIcon(ai)) } catch (x: Exception) { null }
        }.sortedWith(compareByDescending<Row> { it.ms }.thenBy { it.name.lowercase() })
        val total = rows.sumOf { it.ms }
        val sp = Sec.sp(this)
        val allowed = sp.getStringSet("allowed", emptySet()) ?: emptySet()
        val blocked = sp.getStringSet("blocked", emptySet()) ?: emptySet()
        val shown = when (tab) { 1 -> rows.filter { it.ms > 0 }.take(10); 2 -> rows.filter { it.pkg in allowed }; 3 -> rows.filter { it.pkg in blocked }; else -> rows }
        if (shown.isEmpty()) box.addView(TextView(this).apply { text = if (tab >= 2) "No apps marked yet. Tap an app in All Apps to mark it." else "No apps to show"; textSize = 14f; setPadding(30, 30, 30, 30); setTextColor(0xFF44506A.toInt()) })
        val inf = LayoutInflater.from(this)
        shown.forEachIndexed { i, r ->
            val v = inf.inflate(R.layout.item_app, box, false)
            v.findViewById<ImageView>(R.id.aIcon).setImageDrawable(r.icon)
            v.findViewById<TextView>(R.id.aName).text = r.name
            val mark = if (r.pkg in allowed) "  ★" else if (r.pkg in blocked) "  ⛔" else ""
            v.findViewById<TextView>(R.id.aCat).text = r.cat + mark
            val pct = if (total > 0) (r.ms * 100 / total).toInt() else 0
            v.findViewById<TextView>(R.id.aTime).text = "${fmt(r.ms)} ($pct%)"
            v.findViewById<ProgressBar>(R.id.aBar).apply { progress = pct; progressTintList = android.content.res.ColorStateList.valueOf(palette[i % palette.size]) }
            v.setOnClickListener { details(r, pct) }
            box.addView(v)
        }
        findViewById<TextView>(R.id.totalText).text = "Total Apps Usage Time: " + fmt(total)
    }

    private fun mark(pkg: String, key: String, add: Boolean) {
        val sp = Sec.sp(this)
        for (k in listOf("allowed", "blocked")) {
            val set = (sp.getStringSet(k, emptySet()) ?: emptySet()).toMutableSet()
            set.remove(pkg); if (add && k == key) set.add(pkg)
            sp.edit().putStringSet(k, set).apply()
        }
        render()
    }

    private fun details(r: Row, pct: Int) {
        val items = arrayOf("Open App", "App Info (system)", "★ Mark as Allowed", "⛔ Mark as Blocked", "Clear mark")
        AlertDialog.Builder(this).setTitle("${r.name}\n${fmt(r.ms)} ($pct%)  •  ${r.cat}").setItems(items) { _, i ->
            when (i) {
                0 -> packageManager.getLaunchIntentForPackage(r.pkg)?.let { startActivity(it) }
                1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + r.pkg)))
                2 -> mark(r.pkg, "allowed", true)
                3 -> { mark(r.pkg, "blocked", true); Toast.makeText(this, "Marked in your list. Android does not let this app force-close other apps.", Toast.LENGTH_LONG).show() }
                4 -> mark(r.pkg, "", false)
            }
        }.setNegativeButton("Close", null).show()
    }
}
