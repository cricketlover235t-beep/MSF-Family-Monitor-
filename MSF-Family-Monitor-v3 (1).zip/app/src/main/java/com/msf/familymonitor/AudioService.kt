package com.msf.familymonitor

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class AudioService : Service() {
    companion object { var running = false }
    private var rec: MediaRecorder? = null
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("msfa", "Audio recording", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "msfa").setContentTitle("MSF Family Monitor").setContentText("Audio recording is active")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 30) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(2, n)
        val dir = File(getExternalFilesDir(null), "recordings").also { it.mkdirs() }
        val file = File(dir, "Audio_" + SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date()) + ".m4a")
        try {
            rec = (if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC); setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC); setAudioSamplingRate(44100); setAudioEncodingBitRate(intArrayOf(64000, 128000, 192000)[Sec.sp(this@AudioService).getInt("aud_q", 2)]); setOutputFile(file.absolutePath); prepare(); start() }
            running = true
        } catch (e: Exception) { stopSelf() }
        return START_NOT_STICKY
    }
    override fun onDestroy() {
        running = false
        try { rec?.stop() } catch (_: Exception) {}
        rec?.release(); super.onDestroy()
    }
}
