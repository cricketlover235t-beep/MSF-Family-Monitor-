package com.msf.familymonitor

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.io.File

class RecordService : Service() {
    companion object { var running = false }
    private var rec: MediaRecorder? = null
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var w = 0; private var h = 0
    private val handler = Handler(Looper.getMainLooper())
    private var splitMs = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val ch = "msf"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(ch, "Monitoring", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("MSF Family Monitor").setContentText("Screen & audio recording is active")
            .setSmallIcon(android.R.drawable.ic_menu_camera).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        val data = i?.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        proj = mpm.getMediaProjection(Activity.RESULT_OK, data)
        proj?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, null)
        val sp = Sec.sp(this)
        val dm = resources.displayMetrics
        val shortSide = minOf(dm.widthPixels, dm.heightPixels)
        val scale = minOf(1f, sp.getInt("rec_q", 720).toFloat() / shortSide)
        w = (dm.widthPixels * scale).toInt() / 16 * 16; h = (dm.heightPixels * scale).toInt() / 16 * 16
        splitMs = sp.getInt("rec_split", 0) * 60000L
        try {
            rec = newRecorder()
            vd = proj!!.createVirtualDisplay("msf", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rec!!.surface, null, null)
            rec!!.start()
            scheduleSplit()
        } catch (e: Exception) { stopSelf() }
        return START_NOT_STICKY
    }

    private fun newRecorder(): MediaRecorder {
        val file = File(Cleanup.dir(this), "Screen_" + java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", java.util.Locale.US).format(java.util.Date()) + ".mp4")
        val aq = Sec.sp(this).getInt("aud_q", 2)
        return (if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()).apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(intArrayOf(64000, 128000, 192000)[aq]); setAudioSamplingRate(44100)
            setVideoSize(w, h); setVideoFrameRate(24); setVideoEncodingBitRate(w * h * 3)
            setOutputFile(file.absolutePath); prepare()
        }
    }

    private fun scheduleSplit() {
        if (splitMs <= 0) return
        handler.postDelayed({
            try {
                val old = rec; val nr = newRecorder()
                vd?.surface = nr.surface; nr.start(); rec = nr
                try { old?.stop() } catch (_: Exception) {}
                old?.release()
                scheduleSplit()
            } catch (e: Exception) { stopSelf() }
        }, splitMs)
    }

    override fun onDestroy() {
        running = false; handler.removeCallbacksAndMessages(null)
        try { rec?.stop() } catch (_: Exception) {}
        rec?.release(); vd?.release(); proj?.stop()
        super.onDestroy()
    }
}
