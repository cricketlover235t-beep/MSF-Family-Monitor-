package com.msf.familymonitor

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

class DonutView(c: Context, a: AttributeSet? = null) : View(c, a) {
    private var values = floatArrayOf(); private var colors = intArrayOf()
    private var line1 = "0h 0m"; private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    fun set(v: FloatArray, col: IntArray, center: String) { values = v; colors = col; line1 = center; invalidate() }
    override fun onDraw(cv: Canvas) {
        val s = 26f * resources.displayMetrics.density / 2
        val r = RectF(s, s, width - s, height - s)
        p.style = Paint.Style.STROKE; p.strokeWidth = s * 1.6f
        p.color = 0xFFE2E8F5.toInt(); cv.drawArc(r, 0f, 360f, false, p)
        val tot = values.sum()
        if (tot > 0) { var st = -90f
            values.forEachIndexed { i, v -> val sw = v / tot * 360f; p.color = colors[i]; cv.drawArc(r, st, sw, false, p); st += sw } }
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.color = 0xFF111111.toInt(); p.isFakeBoldText = true
        p.textSize = 22f * resources.displayMetrics.density; cv.drawText(line1, width / 2f, height / 2f + 4, p)
        p.isFakeBoldText = false; p.textSize = 11f * resources.displayMetrics.density
        cv.drawText("Total Screen Time", width / 2f, height / 2f + 22f * resources.displayMetrics.density, p)
    }
}
