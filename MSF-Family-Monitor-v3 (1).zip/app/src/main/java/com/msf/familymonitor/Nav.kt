package com.msf.familymonitor

import android.app.Activity
import android.content.Intent
import android.widget.TextView

object Nav {
    fun setup(a: Activity, sel: Int) {
        val items = listOf(R.id.navHome to MainActivity::class.java, R.id.navRec to RecordingsActivity::class.java,
            R.id.navRep to UsageActivity::class.java, R.id.navSet to SettingsActivity::class.java)
        items.forEachIndexed { i, (id, cls) ->
            val tv = a.findViewById<TextView>(id)
            if (i == sel) { tv.setBackgroundResource(R.drawable.bg_nav_sel); tv.setTextColor(0xFFFFD21F.toInt()) }
            tv.setOnClickListener {
                if (i == sel) return@setOnClickListener
                if (i == 0) a.startActivity(Intent(a, cls).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                else { a.startActivity(Intent(a, cls)); if (a !is MainActivity) a.finish() }
            }
        }
    }
}
