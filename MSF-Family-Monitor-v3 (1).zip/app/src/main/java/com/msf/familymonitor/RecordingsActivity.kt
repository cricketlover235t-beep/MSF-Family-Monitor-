package com.msf.familymonitor

import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class RecordingsActivity : AppCompatActivity() {
    private var screenTab = true
    private var files = listOf<File>()
    private val cache = HashMap<String, Pair<String, Bitmap?>>()
    private lateinit var list: ListView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_recordings)
        findViewById<TextView>(R.id.hdrBtn).apply { text = "←"; setOnClickListener { finish() } }
        Nav.setup(this, 1)
        Sec.galleryGuard(this)
        list = findViewById(R.id.list)
        findViewById<View>(R.id.tabScreen).setOnClickListener { screenTab = true; load() }
        findViewById<View>(R.id.tabAudio).setOnClickListener { screenTab = false; load() }
        findViewById<TextView>(R.id.btnAudioRec).setOnClickListener {
            if (checkSelfPermission("android.permission.RECORD_AUDIO") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf("android.permission.RECORD_AUDIO"), 2); return@setOnClickListener }
            val i = Intent(this, AudioService::class.java)
            if (AudioService.running) stopService(i) else startForegroundService(i)
            it.postDelayed({ load() }, 700)
        }
    }

    override fun onResume() { super.onResume(); load() }

    private fun dir() = File(getExternalFilesDir(null), "recordings").also { it.mkdirs() }

    private fun load() {
        val sel = findViewById<TextView>(R.id.tabScreen); val aud = findViewById<TextView>(R.id.tabAudio)
        fun style(t: TextView, on: Boolean) { t.setBackgroundResource(if (on) R.drawable.bg_tab_sel else R.drawable.bg_tab); t.setTextColor(if (on) 0xFFFFFFFF.toInt() else 0xFF0A1F6B.toInt()) }
        style(sel, screenTab); style(aud, !screenTab)
        val ext = if (screenTab) "mp4" else "m4a"
        files = dir().listFiles()?.filter { it.extension == ext }?.sortedByDescending { it.lastModified() } ?: emptyList()
        val btn = findViewById<TextView>(R.id.btnAudioRec)
        btn.visibility = if (screenTab) View.GONE else View.VISIBLE
        btn.text = if (AudioService.running) "⏹  Stop Audio Recording" else "🎙  Start Audio Recording"
        findViewById<View>(R.id.empty).visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
        list.adapter = Adp()
    }

    private fun play(f: File) {
        val uri = FileProvider.getUriForFile(this, "com.msf.familymonitor.files", f)
        val mime = if (f.extension == "mp4") "video/mp4" else "audio/mp4"
        try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
        catch (e: Exception) { Toast.makeText(this, "No player app found", Toast.LENGTH_SHORT).show() }
    }

    inner class Adp : BaseAdapter() {
        override fun getCount() = files.size
        override fun getItem(p: Int) = files[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val v = cv ?: LayoutInflater.from(this@RecordingsActivity).inflate(R.layout.item_recording, parent, false)
            val f = files[p]
            v.findViewById<TextView>(R.id.name).text = f.nameWithoutExtension
            v.findViewById<TextView>(R.id.date).text = "📅 " + SimpleDateFormat("MMM dd, yyyy   hh:mm a", Locale.US).format(Date(f.lastModified()))
            v.findViewById<TextView>(R.id.size).text = "📱 " + (if (f.length() >= 1048576) "%.2f MB".format(f.length() / 1048576.0) else "${f.length() / 1024} KB")
            val thumb = v.findViewById<ImageView>(R.id.thumb); val dur = v.findViewById<TextView>(R.id.dur); val mic = v.findViewById<View>(R.id.mic)
            val video = f.extension == "mp4"
            mic.visibility = if (video) View.GONE else View.VISIBLE
            thumb.setImageBitmap(null); dur.text = "00:00"; thumb.tag = f.path
            val c = cache[f.path]
            if (c != null) { dur.text = c.first; if (video) thumb.setImageBitmap(c.second) }
            else Thread {
                var d = "00:00"; var bmp: Bitmap? = null
                try {
                    val m = MediaMetadataRetriever(); m.setDataSource(f.path)
                    val ms = (m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION) ?: "0").toLong() / 1000
                    d = "%02d:%02d:%02d".format(ms / 3600, ms % 3600 / 60, ms % 60)
                    if (video) bmp = m.getFrameAtTime(0); m.release()
                } catch (_: Exception) {}
                cache[f.path] = Pair(d, bmp)
                runOnUiThread { if (thumb.tag == f.path) { dur.text = d; if (video) thumb.setImageBitmap(bmp) } }
            }.start()
            v.findViewById<View>(R.id.play).setOnClickListener { play(f) }
            v.setOnClickListener { play(f) }
            v.findViewById<View>(R.id.del).setOnClickListener {
                AlertDialog.Builder(this@RecordingsActivity).setTitle("Delete recording?").setMessage(f.name)
                    .setPositiveButton("Delete") { _, _ -> f.delete(); load() }.setNegativeButton("Cancel", null).show()
            }
            return v
        }
    }
}
