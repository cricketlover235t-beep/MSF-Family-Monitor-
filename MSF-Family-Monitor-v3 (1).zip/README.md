# MSF Family Monitor
1. Create a GitHub repo and upload all these files (keep the folder structure).
2. Go to Actions > "Build APK" > Run workflow.
3. Download `MSF-Family-Monitor-APK` from the run's Artifacts.
