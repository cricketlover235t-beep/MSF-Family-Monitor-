package com.msf.familymonitor

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Looks and works like a plain calculator. Entering the app's own PIN and pressing "="
 * opens MSF Family Monitor instead of showing a result — nothing on this screen hints
 * that it does anything else, so it stays safe to leave as the visible icon.
 */
class CalculatorActivity : AppCompatActivity() {
    private lateinit var display: TextView
    private var expr = StringBuilder()
    private val sp by lazy { Sec.sp(this) }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#1C1C1C")) }
        display = TextView(this).apply {
            text = "0"; setTextColor(Color.WHITE); textSize = 44f; gravity = Gravity.END or Gravity.BOTTOM
            setPadding(dp(20), dp(40), dp(20), dp(20))
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        root.addView(display)

        val grid = GridLayout(this).apply { columnCount = 4; rowCount = 5; setPadding(dp(8), dp(8), dp(8), dp(16)) }
        val keys = listOf("C", "⌫", "%", "÷", "7", "8", "9", "×", "4", "5", "6", "−", "1", "2", "3", "+", "00", "0", ".", "=")
        for ((i, k) in keys.withIndex()) {
            val isOp = k in listOf("÷", "×", "−", "+", "=")
            val b = Button(this).apply {
                text = k; textSize = 22f; setTextColor(if (isOp) Color.parseColor("#FF9800") else Color.WHITE)
                setBackgroundColor(if (k == "C" || k == "⌫" || k == "%") Color.parseColor("#3A3A3A") else Color.parseColor("#2B2B2B"))
                setOnClickListener { press(k) }
            }
            val lp = GridLayout.LayoutParams(GridLayout.spec(i / 4, 1f), GridLayout.spec(i % 4, 1f))
            lp.width = 0; lp.height = dp(68); lp.setMargins(dp(4), dp(4), dp(4), dp(4))
            b.layoutParams = lp
            grid.addView(b)
        }
        root.addView(grid)
        setContentView(root)
    }

    private fun press(k: String) {
        when (k) {
            "C" -> { expr.clear(); display.text = "0" }
            "⌫" -> { if (expr.isNotEmpty()) expr.deleteCharAt(expr.length - 1); display.text = if (expr.isEmpty()) "0" else expr.toString() }
            "=" -> onEquals()
            else -> { expr.append(k); display.text = expr.toString() }
        }
    }

    private fun onEquals() {
        val raw = expr.toString()
        val pin = sp.getString("pin", null)
        if (pin != null && raw == pin) {
            expr.clear(); display.text = "0"
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
            finish()
            return
        }
        display.text = try { evaluate(raw).let { if (it == it.toLong().toDouble()) it.toLong().toString() else it.toString() } } catch (e: Exception) { "Error" }
        expr.clear(); if (display.text != "Error") expr.append(display.text)
    }

    // tiny left-to-right evaluator: handles + − × ÷ % with no operator precedence, enough for a decoy calculator
    private fun evaluate(s: String): Double {
        val tokens = Regex("(\\d+\\.?\\d*|[+−×÷%])").findAll(s).map { it.value }.toList()
        if (tokens.isEmpty()) return 0.0
        var result = tokens[0].toDouble()
        var i = 1
        while (i < tokens.size - 1) {
            val op = tokens[i]; val n = tokens[i + 1].toDouble()
            result = when (op) { "+" -> result + n; "−" -> result - n; "×" -> result * n; "÷" -> result / n; "%" -> result % n; else -> result }
            i += 2
        }
        return result
    }
}
