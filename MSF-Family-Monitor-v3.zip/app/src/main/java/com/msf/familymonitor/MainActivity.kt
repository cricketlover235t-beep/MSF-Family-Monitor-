package com.msf.familymonitor

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var toggle: TextView
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        Sec.gOk = false; Sec.appGuard(this); Cleanup.run(this)
        toggle = findViewById(R.id.btnToggle); status = findViewById(R.id.tvStatus)
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS", "android.permission.RECORD_AUDIO"), 1)
        else requestPermissions(arrayOf("android.permission.RECORD_AUDIO"), 1)

        toggle.setOnClickListener {
            if (RecordService.running) {
                stopService(Intent(this, RecordService::class.java)); RecordService.running = false; refresh()
            } else {
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mpm.createScreenCaptureIntent(), 100)
            }
        }
        fun open(mode: String) = startActivity(Intent(this, ListActivity::class.java).putExtra("mode", mode))
        fun v(id: Int): View = findViewById(id)
        v(R.id.tRec).setOnClickListener { startActivity(Intent(this, RecordingsActivity::class.java)) }
        v(R.id.nRec).setOnClickListener { startActivity(Intent(this, RecordingsActivity::class.java)) }
        v(R.id.tUsage).setOnClickListener { startActivity(Intent(this, UsageActivity::class.java)) }
        v(R.id.nRep).setOnClickListener { startActivity(Intent(this, UsageActivity::class.java)) }
        v(R.id.tApps).setOnClickListener { startActivity(Intent(this, AppsActivity::class.java)) }
        v(R.id.tSet).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        v(R.id.btnGear).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        v(R.id.tLock).setOnClickListener { startActivity(Intent(this, RecordingsActivity::class.java)) }
        v(R.id.tAbout).setOnClickListener {
            AlertDialog.Builder(this).setTitle("MSF Family Monitor").setMessage("Version 1.0\nA transparent parental-monitoring app. Recording always shows a notification on the child's phone.").setPositiveButton("OK", null).show()
        }
        v(R.id.nHelp).setOnClickListener {
            AlertDialog.Builder(this).setTitle("Help").setMessage("1. Tap OFF/ON to start or stop screen & audio recording.\n2. Usage Report needs 'Usage access' permission (Settings).\n3. Lock Gallery is protected by your PIN.").setPositiveButton("OK", null).show()
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val on = RecordService.running
        toggle.text = if (on) "ON" else "OFF"
        toggle.setBackgroundResource(if (on) R.drawable.bg_on else R.drawable.bg_off)
        status.text = if (on) "Monitoring Active" else "Monitoring Inactive"
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        if (r == 100 && res == Activity.RESULT_OK && d != null) {
            val i = Intent(this, RecordService::class.java).putExtra("data", d)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            RecordService.running = true; refresh()
        } else Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
    }

    private fun askPin() {
        val sp = getSharedPreferences("msf", MODE_PRIVATE)
        val saved = sp.getString("pin", null)
        val et = android.widget.EditText(this).apply { inputType = 0x12; hint = "PIN" }
        AlertDialog.Builder(this).setTitle(if (saved == null) "Set a new PIN" else "Enter PIN").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val p = et.text.toString()
                if (saved == null && p.length >= 4) { sp.edit().putString("pin", p).apply(); startActivity(Intent(this, RecordingsActivity::class.java)) }
                else if (saved == p) startActivity(Intent(this, RecordingsActivity::class.java))
                else Toast.makeText(this, "Wrong PIN (min 4 digits)", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }
}
