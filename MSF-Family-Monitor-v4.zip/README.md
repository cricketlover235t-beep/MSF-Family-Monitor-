# MSF Family Monitor (v4)
1. Create a GitHub repo and upload all these files (keep the folder structure).
2. Go to Actions > "Build APK" > Run workflow.
3. Download `MSF-Family-Monitor-APK` from the run's Artifacts.

## What's new in v4
- Full-screen Home and a new Lock Gallery screen, designed like the supplied pictures.
- Auto parts: records 30 min, saves, waits 1 min, records the next 30 min (Settings > Auto Recording / Gap Between Parts). Works for video and audio.
- Share button on every file (Recordings and Lock Gallery): Bluetooth, Quick/Nearby Share, WhatsApp, etc.
- Optional: Settings > "Auto Audio with Monitoring" starts audio recording together with Monitoring ON.
- Usage report can be saved as PDF into Lock Gallery.
