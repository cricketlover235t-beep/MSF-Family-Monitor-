package com.msf.familymonitor

import android.app.Activity
import android.content.Intent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView

object Nav {
    /** sel: 0 Home, 1 Recordings, 2 Reports, 3 Lock Gallery / Help, -1 none. */
    fun setup(a: Activity, sel: Int) {
        val fourth = if (a.findViewById<View>(R.id.navLock) != null) R.id.navLock else R.id.navHelp
        val items = listOf(R.id.navHome to MainActivity::class.java, R.id.navRec to RecordingsActivity::class.java,
            R.id.navRep to UsageActivity::class.java, fourth to GalleryActivity::class.java)
        items.forEachIndexed { i, (id, cls) ->
            val v = a.findViewById<ViewGroup>(id) ?: return@forEachIndexed
            if (i == sel) {
                v.setBackgroundResource(R.drawable.bg_nav_sel)
                (v.getChildAt(0) as ImageView).setColorFilter(0xFFFFD21F.toInt())
                (v.getChildAt(1) as TextView).setTextColor(0xFFFFD21F.toInt())
            }
            if (id == R.id.navHelp) return@forEachIndexed   // Help is handled by MainActivity
            v.setOnClickListener {
                if (i == sel) return@setOnClickListener
                if (i == 0) a.startActivity(Intent(a, cls).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                else { a.startActivity(Intent(a, cls)); if (a !is MainActivity) a.finish() }
            }
        }
    }
}
