package com.msf.familymonitor

import android.app.usage.UsageStatsManager
import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

/** Saves one day's app-usage report as a PDF inside the secure recordings folder. */
object ReportPdf {
    fun create(c: Context, day: Calendar): File? {
        try {
            val s = (day.clone() as Calendar).apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
            val e = minOf(s + 86400000L - 1, System.currentTimeMillis())
            val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val pm = c.packageManager
            val rows = usm.queryAndAggregateUsageStats(s, e).values
                .filter { it.totalTimeInForeground > 60000 && it.packageName != c.packageName }
                .sortedByDescending { it.totalTimeInForeground }
                .map { u ->
                    val name = try { pm.getApplicationLabel(pm.getApplicationInfo(u.packageName, 0)).toString() } catch (x: Exception) { u.packageName }
                    Pair(name, u.totalTimeInForeground)
                }
            if (rows.isEmpty() && !hasAccess(c)) return null
            val total = rows.sumOf { it.second }
            fun fmt(ms: Long) = "${ms / 3600000}h ${ms / 60000 % 60}m"

            val doc = PdfDocument()
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            var pageNo = 1
            var page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
            var cv = page.canvas
            fun header() {
                p.color = Color.parseColor("#0A1F6B"); cv.drawRect(0f, 0f, 595f, 90f, p)
                p.color = Color.WHITE; p.typeface = Typeface.DEFAULT_BOLD; p.textSize = 24f; cv.drawText("MSF Family Monitor", 30f, 40f, p)
                p.typeface = Typeface.DEFAULT; p.textSize = 14f
                cv.drawText("Usage Report  -  " + SimpleDateFormat("EEE, MMM dd yyyy", Locale.US).format(day.time), 30f, 68f, p)
            }
            header()
            var y = 125f
            p.color = Color.BLACK; p.typeface = Typeface.DEFAULT_BOLD; p.textSize = 16f
            cv.drawText("Total screen time: " + fmt(total), 30f, y, p); y += 34f
            p.textSize = 12f; p.color = Color.parseColor("#44506A")
            cv.drawText("App", 30f, y, p); cv.drawText("Time", 380f, y, p); cv.drawText("Share", 500f, y, p); y += 8f
            p.color = Color.parseColor("#9DBBF5"); cv.drawLine(30f, y, 565f, y, p); y += 20f
            if (rows.isEmpty()) { p.color = Color.BLACK; p.typeface = Typeface.DEFAULT; cv.drawText("No app usage recorded for this date.", 30f, y, p) }
            for ((name, ms) in rows) {
                if (y > 800f) {
                    doc.finishPage(page); pageNo++
                    page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create()); cv = page.canvas; header(); y = 125f
                }
                p.color = Color.BLACK; p.typeface = Typeface.DEFAULT; p.textSize = 13f
                cv.drawText(if (name.length > 38) name.take(37) + "..." else name, 30f, y, p)
                cv.drawText(fmt(ms), 380f, y, p)
                cv.drawText((if (total > 0) ms * 100 / total else 0).toString() + "%", 500f, y, p)
                y += 24f
            }
            doc.finishPage(page)
            val f = File(Cleanup.dir(c), "Usage_Report_" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(day.time) + ".pdf")
            FileOutputStream(f).use { doc.writeTo(it) }
            doc.close()
            return f
        } catch (x: Exception) { return null }
    }

    private fun hasAccess(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        return ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.packageName) == android.app.AppOpsManager.MODE_ALLOWED
    }
}
