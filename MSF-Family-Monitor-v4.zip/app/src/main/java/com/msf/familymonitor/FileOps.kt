package com.msf.familymonitor

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/** Open / share / info helpers shared by the Recordings and Lock Gallery screens. */
object FileOps {
    private val cache = HashMap<String, Pair<String, Bitmap?>>()
    private val main = Handler(Looper.getMainLooper())

    fun mime(f: File): String = when (f.extension.lowercase()) {
        "mp4" -> "video/mp4"; "m4a" -> "audio/mp4"; "pdf" -> "application/pdf"; else -> "*/*"
    }

    fun uri(c: Context, f: File): Uri = FileProvider.getUriForFile(c, "com.msf.familymonitor.files", f)

    /** True while the file is still being written by a running recorder. */
    fun busy(f: File): Boolean = f.absolutePath == RecordService.currentPath || f.absolutePath == AudioService.currentPath

    fun size(f: File): String =
        if (f.length() >= 1048576) "%.1f MB".format(f.length() / 1048576.0) else "${maxOf(1L, f.length() / 1024)} KB"

    fun dur(sec: Long): String =
        if (sec >= 3600) "%d:%02d:%02d".format(sec / 3600, sec % 3600 / 60, sec % 60) else "%02d:%02d".format(sec / 60, sec % 60)

    private fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_LONG).show()

    fun open(c: Context, f: File) {
        if (busy(f)) { toast(c, "This part is still being recorded. Try again after it finishes."); return }
        try {
            c.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri(c, f), mime(f)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) { toast(c, "No app found to open this file") }
    }

    /** Opens the Android share sheet: Bluetooth, Quick/Nearby Share, WhatsApp, Telegram, email, Drive... */
    fun share(c: Context, files: List<File>) {
        val ok = files.filter { it.exists() && !busy(it) }
        if (ok.isEmpty()) { toast(c, "Nothing to share yet. The file is still being recorded."); return }
        try {
            val uris = ArrayList<Uri>(ok.map { uri(c, it) })
            val send = Intent(if (uris.size == 1) Intent.ACTION_SEND else Intent.ACTION_SEND_MULTIPLE)
            val types = ok.map { mime(it) }.distinct()
            send.type = if (types.size == 1) types[0] else "*/*"
            if (uris.size == 1) send.putExtra(Intent.EXTRA_STREAM, uris[0]) else send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            send.putExtra(Intent.EXTRA_SUBJECT, "MSF Family Monitor - " + ok[0].name)
            val clip = ClipData.newRawUri(ok[0].name, uris[0])
            for (i in 1 until uris.size) clip.addItem(ClipData.Item(uris[i]))
            send.clipData = clip
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            c.startActivity(Intent.createChooser(send, "Share via (Bluetooth, WhatsApp, Nearby Share...)"))
        } catch (e: Exception) { toast(c, "Could not share this file") }
    }

    /** Duration + small thumbnail, loaded off the main thread and cached. */
    fun meta(f: File, withFrame: Boolean, cb: (String, Bitmap?) -> Unit) {
        val key = f.path + "|" + f.length() + "|" + f.lastModified()
        val hit = synchronized(cache) { cache[key] }
        if (hit != null) { cb(hit.first, hit.second); return }
        Thread {
            var d = "00:00"; var bmp: Bitmap? = null
            try {
                val m = MediaMetadataRetriever(); m.setDataSource(f.path)
                val ms = (m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION) ?: "0").toLong() / 1000
                d = dur(ms)
                if (withFrame) {
                    val fr = m.getFrameAtTime(0)
                    if (fr != null) { bmp = Bitmap.createScaledBitmap(fr, 220, (220f * fr.height / fr.width).toInt().coerceAtLeast(1), true); if (bmp !== fr) fr.recycle() }
                }
                m.release()
            } catch (_: Exception) {}
            synchronized(cache) { cache[key] = Pair(d, bmp) }
            main.post { cb(d, bmp) }
        }.start()
    }
}
