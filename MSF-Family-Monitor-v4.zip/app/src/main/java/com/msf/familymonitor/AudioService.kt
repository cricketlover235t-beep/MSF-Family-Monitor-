package com.msf.familymonitor

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/** Audio-only recording, automatic parts: 30 min -> save -> 1 min gap -> next part (same rule as video). */
class AudioService : Service() {
    companion object { var running = false; var currentPath: String? = null }
    private var rec: MediaRecorder? = null
    private val handler = Handler(Looper.getMainLooper())
    private var splitMs = 0L
    private var gapMs = 0L
    private var wl: PowerManager.WakeLock? = null
    private var curFile: File? = null
    override fun onBind(i: Intent?): IBinder? = null

    private fun notif(text: String): Notification =
        NotificationCompat.Builder(this, "msfa").setContentTitle("MSF Family Monitor").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()

    private fun say(text: String) { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(2, notif(text)) }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (Build.VERSION.SDK_INT >= 26)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel("msfa", "Audio recording", NotificationManager.IMPORTANCE_LOW))
        val n = notif("Audio recording is active")
        if (Build.VERSION.SDK_INT >= 30) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(2, n)
        if (running) return START_NOT_STICKY
        val sp = Sec.sp(this)
        splitMs = sp.getInt("rec_split", 30) * 60000L
        gapMs = sp.getInt("rec_gap", 1) * 60000L
        try { wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "msf:aud").apply { acquire() } } catch (_: Exception) {}
        try { rec = newRecorder(); rec!!.start(); running = true; scheduleEnd() } catch (e: Exception) { stopSelf() }
        return START_NOT_STICKY
    }

    private fun newRecorder(): MediaRecorder {
        val file = File(Cleanup.dir(this), "Audio_" + SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date()) + ".m4a")
        curFile = file; currentPath = file.absolutePath
        return (if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()).apply {
            setAudioSource(MediaRecorder.AudioSource.MIC); setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC); setAudioSamplingRate(44100)
            setAudioEncodingBitRate(intArrayOf(64000, 128000, 192000)[Sec.sp(this@AudioService).getInt("aud_q", 2)])
            setOutputFile(file.absolutePath); prepare()
        }
    }

    private fun finishPart() {
        try { rec?.stop() } catch (_: Exception) { curFile?.delete() }
        try { rec?.release() } catch (_: Exception) {}
        rec = null; currentPath = null
    }

    private fun scheduleEnd() { if (splitMs > 0) handler.postDelayed({ endPart() }, splitMs) }

    private fun endPart() {
        finishPart()
        if (gapMs <= 0) { startPart(); return }
        say("Part saved. Next part starts in ${gapMs / 60000} min")
        handler.postDelayed({ startPart() }, gapMs)
    }

    private fun startPart() {
        try { val r = newRecorder(); r.start(); rec = r; say("Audio recording is active"); scheduleEnd() } catch (e: Exception) { stopSelf() }
    }

    override fun onDestroy() {
        running = false; handler.removeCallbacksAndMessages(null)
        finishPart()
        try { wl?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        super.onDestroy()
    }
}
