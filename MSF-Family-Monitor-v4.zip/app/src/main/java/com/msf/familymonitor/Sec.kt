package com.msf.familymonitor

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import java.io.File

object Sec {
    var gOk = false
    var aOk = false
    fun sp(c: Context) = c.getSharedPreferences("msf", Context.MODE_PRIVATE)

    fun input(a: Context, title: String, cb: (String) -> Unit) {
        val et = EditText(a).apply { inputType = 0x12; hint = "PIN" }
        AlertDialog.Builder(a).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> cb(et.text.toString()) }.setNegativeButton("Cancel", null).show()
    }

    private fun gate(a: Activity, title: String, check: (String) -> Boolean, onCancel: () -> Unit) {
        val et = EditText(a).apply { inputType = 0x12; hint = "PIN" }
        AlertDialog.Builder(a).setTitle(title).setView(et).setCancelable(false)
            .setPositiveButton("OK") { _, _ ->
                if (!check(et.text.toString())) { Toast.makeText(a, "Wrong or invalid PIN", Toast.LENGTH_SHORT).show(); gate(a, title, check, onCancel) }
            }.setNegativeButton("Cancel") { _, _ -> onCancel() }.show()
    }

    fun galleryGuard(a: Activity) {
        val s = sp(a)
        if (!s.getBoolean("secure", true) || gOk) return
        val pin = s.getString("pin", null)
        if (pin == null) gate(a, "Set a new PIN (min 4 digits)", { p -> if (p.length >= 4) { s.edit().putString("pin", p).apply(); gOk = true; true } else false }) { a.finish() }
        else gate(a, "Enter PIN", { p -> if (p == pin) { gOk = true; true } else false }) { a.finish() }
    }

    fun appGuard(a: Activity) {
        val ppw = sp(a).getString("ppw", null)
        if (ppw == null || aOk) return
        gate(a, "Parental Password", { p -> if (p == ppw) { aOk = true; true } else false }) { a.finish() }
    }
}

object Cleanup {
    fun dir(c: Context) = File(c.getExternalFilesDir(null), "recordings").also { it.mkdirs() }
    fun run(c: Context) { val d = Sec.sp(c).getInt("cleanup", 0); if (d > 0) delete(c, d) }
    fun delete(c: Context, days: Int): Int {
        val cut = System.currentTimeMillis() - days * 86400000L
        return dir(c).listFiles()?.filter { it.lastModified() < cut }?.count { it.delete() } ?: 0
    }
}

object Monitor {
    const val REQ = 100
    private fun micOk(c: Context) = c.checkSelfPermission("android.permission.RECORD_AUDIO") == android.content.pm.PackageManager.PERMISSION_GRANTED

    fun toggle(a: Activity) { if (RecordService.running) stop(a) else request(a) }

    fun stop(a: Context) {
        a.stopService(Intent(a, RecordService::class.java)); RecordService.running = false
        if (Sec.sp(a).getBoolean("auto_audio", false)) a.stopService(Intent(a, AudioService::class.java))
    }

    @Suppress("DEPRECATION")
    fun request(a: Activity) {
        if (!micOk(a)) {
            a.requestPermissions(arrayOf("android.permission.RECORD_AUDIO"), 1)
            Toast.makeText(a, "Allow the microphone first, then tap ON again", Toast.LENGTH_LONG).show(); return
        }
        val m = a.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        a.startActivityForResult(m.createScreenCaptureIntent(), REQ)
    }

    fun onResult(a: Activity, req: Int, res: Int, d: Intent?) {
        if (req != REQ) return
        if (res == Activity.RESULT_OK && d != null) {
            a.startForegroundService(Intent(a, RecordService::class.java).putExtra("data", d)); RecordService.running = true
            if (Sec.sp(a).getBoolean("auto_audio", false) && !AudioService.running && micOk(a)) a.startForegroundService(Intent(a, AudioService::class.java))
        } else Toast.makeText(a, "Permission denied", Toast.LENGTH_SHORT).show()
    }
}
