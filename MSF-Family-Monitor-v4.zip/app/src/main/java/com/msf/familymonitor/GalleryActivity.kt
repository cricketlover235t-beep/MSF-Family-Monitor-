package com.msf.familymonitor

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class GalleryActivity : AppCompatActivity() {
    private var filter = ""            // "", "mp4", "m4a", "pdf"
    private var day: Calendar? = null
    private var showAll = false

    private fun sp() = Sec.sp(this)
    private fun secureOn() = sp().getBoolean("secure", true)
    private fun unlocked() = !secureOn() || Sec.gOk
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun need(): Boolean { if (unlocked()) return true; toast("Enter Parent PIN first"); return false }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_gallery)
        findViewById<TextView>(R.id.hdrBtn).apply { text = "⚙"; setOnClickListener { startActivity(Intent(context, SettingsActivity::class.java)) } }
        Nav.setup(this, 3)
        findViewById<View>(R.id.btnUnlock).setOnClickListener { onUnlock() }
        findViewById<EditText>(R.id.etPin).setOnEditorActionListener { _, _, _ -> onUnlock(); true }
        mapOf(R.id.fVideo to "mp4", R.id.fAudio to "m4a", R.id.fReport to "pdf").forEach { (id, ext) ->
            findViewById<View>(id).setOnClickListener {
                if (!need()) return@setOnClickListener
                filter = if (filter == ext) "" else ext; showAll = false; refresh()
            }
        }
        findViewById<View>(R.id.dateBtn).setOnClickListener {
            if (!need()) return@setOnClickListener
            val c = day ?: Calendar.getInstance()
            DatePickerDialog(this, { _, y, m, d -> day = Calendar.getInstance().apply { set(y, m, d) }; refresh() },
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).apply { datePicker.maxDate = System.currentTimeMillis() }.show()
        }
        findViewById<View>(R.id.dateClear).setOnClickListener { day = null; refresh() }
        findViewById<View>(R.id.viewAll).setOnClickListener { if (need()) { showAll = !showAll; refresh() } }
        findViewById<View>(R.id.btnMakeReport).setOnClickListener {
            if (!need()) return@setOnClickListener
            val f = ReportPdf.create(this, Calendar.getInstance())
            if (f == null) toast("Enable Usage access first (Reports screen)") else { toast("Saved " + f.name); refresh() }
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun onUnlock() {
        if (!secureOn()) return
        val et = findViewById<EditText>(R.id.etPin)
        if (Sec.gOk) { Sec.gOk = false; et.setText(""); refresh(); return }
        val pin = sp().getString("pin", null); val e = et.text.toString()
        if (pin == null) {
            if (e.length >= 4) { sp().edit().putString("pin", e).apply(); Sec.gOk = true; toast("PIN saved") } else { toast("PIN must be at least 4 digits"); return }
        } else if (e == pin) Sec.gOk = true else { toast("Wrong PIN"); et.setText(""); return }
        et.setText("")
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(et.windowToken, 0)
        refresh()
    }

    private fun sameDay(t: Long, c: Calendar): Boolean {
        val a = Calendar.getInstance().apply { timeInMillis = t }
        return a.get(Calendar.YEAR) == c.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == c.get(Calendar.DAY_OF_YEAR)
    }

    private fun refresh() {
        val ok = unlocked()
        val et = findViewById<EditText>(R.id.etPin); val btn = findViewById<TextView>(R.id.btnUnlock); val title = findViewById<TextView>(R.id.pinTitle)
        val hasPin = sp().getString("pin", null) != null
        when {
            !secureOn() -> { title.text = "Secure Gallery is OFF (see Settings)"; et.visibility = View.GONE; btn.visibility = View.GONE }
            ok -> { title.text = "Gallery Unlocked"; et.visibility = View.GONE; btn.visibility = View.VISIBLE; btn.text = "Lock  ›" }
            else -> { title.text = if (hasPin) "Enter Parent PIN to Access Gallery" else "Set a new PIN (min 4 digits)"; et.visibility = View.VISIBLE; btn.visibility = View.VISIBLE; btn.text = if (hasPin) "Unlock  ›" else "Set PIN  ›" }
        }
        val all = (Cleanup.dir(this).listFiles()?.filter { it.isFile && it.extension in listOf("mp4", "m4a", "pdf") } ?: emptyList()).sortedByDescending { it.lastModified() }
        findViewById<TextView>(R.id.cVideo).text = "${all.count { it.extension == "mp4" }} Videos"
        findViewById<TextView>(R.id.cAudio).text = "${all.count { it.extension == "m4a" }} Audio Files"
        findViewById<TextView>(R.id.cReport).text = "${all.count { it.extension == "pdf" }} Reports"
        mapOf(R.id.fVideo to "mp4", R.id.fAudio to "m4a", R.id.fReport to "pdf").forEach { (id, ext) ->
            findViewById<View>(id).setBackgroundResource(if (filter == ext) R.drawable.bg_folder_sel else R.drawable.bg_folder)
        }
        findViewById<TextView>(R.id.dateText).text = day?.let { SimpleDateFormat("MMM dd, yyyy", Locale.US).format(it.time) } ?: "Select Date"
        findViewById<View>(R.id.dateClear).visibility = if (day != null) View.VISIBLE else View.GONE
        findViewById<View>(R.id.btnMakeReport).visibility = if (ok && filter == "pdf") View.VISIBLE else View.GONE

        // storage
        val st = StatFs(Environment.getDataDirectory().path)
        val tot = (st.blockCountLong * st.blockSizeLong).coerceAtLeast(1L)
        val used = all.sumOf { it.length() }
        val usedS = if (used >= 1073741824L) "%.1f GB".format(used / 1073741824.0) else "%.1f MB".format(used / 1048576.0)
        findViewById<TextView>(R.id.storText).text = "Secure Storage: $usedS / ${"%.0f".format(tot / 1e9)} GB"
        findViewById<ProgressBar>(R.id.storBar).progress = if (used > 0) maxOf(8, (used * 1000 / tot).toInt()) else 0

        // list
        val box = findViewById<LinearLayout>(R.id.gList); box.removeAllViews()
        val titleTxt = findViewById<TextView>(R.id.listTitle); val va = findViewById<TextView>(R.id.viewAll)
        titleTxt.text = when (filter) { "mp4" -> "Screen Recordings"; "m4a" -> "Audio Recordings"; "pdf" -> "Usage Reports"; else -> "Recent Files" }
        if (!ok) {
            va.visibility = View.GONE
            box.addView(TextView(this).apply { text = "🔒  Unlock with Parent PIN to see the files."; textSize = 14f; setTextColor(0xFF44506A.toInt()); setPadding(24, 28, 24, 28); gravity = android.view.Gravity.CENTER })
            return
        }
        va.visibility = View.VISIBLE
        var shown = all.filter { filter == "" || it.extension == filter }
        day?.let { d -> shown = shown.filter { sameDay(it.lastModified(), d) } }
        val limited = !showAll && filter == "" && day == null
        va.text = if (showAll) "Show Less  ›" else "View All  ›"
        if (limited) shown = shown.take(3)
        if (shown.isEmpty()) box.addView(TextView(this).apply { text = "No files found"; textSize = 14f; setTextColor(0xFF44506A.toInt()); setPadding(24, 28, 24, 28); gravity = android.view.Gravity.CENTER })
        val inf = LayoutInflater.from(this)
        shown.forEach { f -> box.addView(row(inf, box, f)) }
    }

    private fun row(inf: LayoutInflater, parent: LinearLayout, f: File): View {
        val v = inf.inflate(R.layout.item_gallery, parent, false)
        val thumb = v.findViewById<ImageView>(R.id.gThumb); val ov = v.findViewById<View>(R.id.gOverlay)
        val info = v.findViewById<TextView>(R.id.gInfo)
        v.findViewById<TextView>(R.id.gName).text = f.name
        val date = SimpleDateFormat("MMM dd, yyyy", Locale.US).format(Date(f.lastModified()))
        val base = "📅 $date  |  "
        val sz = FileOps.size(f)
        when (f.extension) {
            "mp4" -> {
                thumb.setImageDrawable(null); ov.visibility = View.VISIBLE
                info.text = base + "💾 " + sz
                FileOps.meta(f, true) { d, bmp -> info.text = "$base⏱ $d  |  💾 $sz"; if (bmp != null) thumb.setImageBitmap(bmp) }
            }
            "m4a" -> {
                ov.visibility = View.GONE; thumb.setBackgroundResource(R.drawable.bg_thumb_audio)
                thumb.scaleType = ImageView.ScaleType.CENTER_INSIDE; thumb.setPadding(14, 14, 14, 14); thumb.setImageResource(R.drawable.ic_mic)
                info.text = base + "💾 " + sz
                FileOps.meta(f, false) { d, _ -> info.text = "$base⏱ $d  |  💾 $sz" }
            }
            else -> {
                ov.visibility = View.GONE; thumb.setBackgroundResource(R.drawable.bg_thumb_pdf)
                thumb.scaleType = ImageView.ScaleType.CENTER_INSIDE; thumb.setPadding(12, 12, 12, 12); thumb.setImageResource(R.drawable.ic_pdf); thumb.setColorFilter(0xFFDC2626.toInt())
                info.text = base + "💾 " + sz
            }
        }
        v.findViewById<View>(R.id.gPlay).setOnClickListener { FileOps.open(this, f) }
        v.setOnClickListener { FileOps.open(this, f) }
        v.findViewById<View>(R.id.gShare).setOnClickListener { FileOps.share(this, listOf(f)) }
        v.findViewById<View>(R.id.gDel).setOnClickListener {
            if (FileOps.busy(f)) { toast("Recording in progress. Stop monitoring first."); return@setOnClickListener }
            AlertDialog.Builder(this).setTitle("Delete file?").setMessage(f.name)
                .setPositiveButton("Delete") { _, _ -> f.delete(); refresh() }.setNegativeButton("Cancel", null).show()
        }
        return v
    }
}
