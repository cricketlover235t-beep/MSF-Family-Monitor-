package com.msf.familymonitor

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Screen + mic recording in automatic parts.
 * Default: record 30 min -> stop & save -> wait 1 min -> record the next 30 min -> ... until monitoring is turned OFF.
 */
class RecordService : Service() {
    companion object { var running = false; var currentPath: String? = null }
    private var rec: MediaRecorder? = null
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var w = 0; private var h = 0
    private val handler = Handler(Looper.getMainLooper())
    private var splitMs = 0L
    private var gapMs = 0L
    private var wl: PowerManager.WakeLock? = null
    private var curFile: File? = null

    override fun onBind(i: Intent?): IBinder? = null

    private fun notif(text: String): Notification =
        NotificationCompat.Builder(this, "msf").setContentTitle("MSF Family Monitor").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_camera).setOngoing(true).build()

    private fun say(text: String) { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, notif(text)) }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (Build.VERSION.SDK_INT >= 26)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel("msf", "Monitoring", NotificationManager.IMPORTANCE_LOW))
        val n = notif("Screen & audio recording is active")
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        if (proj != null) return START_NOT_STICKY            // already running
        val data = i?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        proj = mpm.getMediaProjection(Activity.RESULT_OK, data)
        proj?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, null)
        val sp = Sec.sp(this)
        val dm = resources.displayMetrics
        val shortSide = minOf(dm.widthPixels, dm.heightPixels)
        val scale = minOf(1f, sp.getInt("rec_q", 720).toFloat() / shortSide)
        w = (dm.widthPixels * scale).toInt() / 16 * 16; h = (dm.heightPixels * scale).toInt() / 16 * 16
        splitMs = sp.getInt("rec_split", 30) * 60000L
        gapMs = sp.getInt("rec_gap", 1) * 60000L
        try {
            wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "msf:rec").apply { acquire() }
        } catch (_: Exception) {}
        try {
            val r = newRecorder()
            vd = proj!!.createVirtualDisplay("msf", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
            r.start(); rec = r; running = true
            scheduleEnd()
        } catch (e: Exception) { stopSelf() }
        return START_NOT_STICKY
    }

    private fun newRecorder(): MediaRecorder {
        val file = File(Cleanup.dir(this), "Screen_" + SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date()) + ".mp4")
        curFile = file; currentPath = file.absolutePath
        val aq = Sec.sp(this).getInt("aud_q", 2)
        return (if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()).apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(intArrayOf(64000, 128000, 192000)[aq]); setAudioSamplingRate(44100)
            setVideoSize(w, h); setVideoFrameRate(24); setVideoEncodingBitRate(w * h * 3)
            setOutputFile(file.absolutePath); prepare()
        }
    }

    /** Stops and saves the current part (the screen capture itself stays alive). */
    private fun finishPart() {
        try { vd?.setSurface(null) } catch (_: Exception) {}
        try { rec?.stop() } catch (_: Exception) { curFile?.delete() }
        try { rec?.release() } catch (_: Exception) {}
        rec = null; currentPath = null
    }

    private fun scheduleEnd() {
        if (splitMs <= 0) return
        handler.postDelayed({ endPart() }, splitMs)
    }

    private fun endPart() {
        finishPart()
        if (gapMs <= 0) { startPart(); return }
        say("Part saved. Next part starts in ${gapMs / 60000} min")
        handler.postDelayed({ startPart() }, gapMs)
    }

    private fun startPart() {
        try {
            val r = newRecorder()
            vd?.setSurface(r.surface)
            r.start(); rec = r
            say("Screen & audio recording is active")
            scheduleEnd()
        } catch (e: Exception) { stopSelf() }
    }

    override fun onDestroy() {
        running = false; handler.removeCallbacksAndMessages(null)
        finishPart()
        try { vd?.release() } catch (_: Exception) {}
        try { proj?.stop() } catch (_: Exception) {}
        try { wl?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        super.onDestroy()
    }
}
