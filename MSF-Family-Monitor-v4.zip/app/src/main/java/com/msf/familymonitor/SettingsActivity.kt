package com.msf.familymonitor

import android.app.AppOpsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class SettingsActivity : AppCompatActivity() {
    private lateinit var box: LinearLayout
    private val sp by lazy { Sec.sp(this) }
    private val UR = mapOf(
        "Settings" to "سیٹنگز", "Configure Your MSF Family Monitor" to "اپنے MSF فیملی مانیٹر کو ترتیب دیں",
        "Monitoring Settings" to "مانیٹرنگ سیٹنگز", "Monitoring ON / OFF" to "مانیٹرنگ آن / آف", "Screen Recording Permission" to "اسکرین ریکارڈنگ کی اجازت",
        "Auto Recording Settings" to "خودکار ریکارڈنگ", "Recording Quality" to "ریکارڈنگ کوالٹی", "Audio Settings" to "آڈیو سیٹنگز",
        "Audio Recording Permission" to "آڈیو ریکارڈنگ کی اجازت", "Audio Quality" to "آڈیو کوالٹی", "Recording Status Indicator" to "ریکارڈنگ اسٹیٹس انڈیکیٹر",
        "Security Settings" to "سیکیورٹی سیٹنگز", "Parental Password" to "پیرنٹل پاس ورڈ", "Change PIN" to "پن تبدیل کریں", "Secure Gallery" to "محفوظ گیلری",
        "App Permissions Details" to "ایپ کی اجازتیں", "Storage Settings" to "اسٹوریج سیٹنگز", "Saved Videos" to "محفوظ ویڈیوز", "Storage Details" to "اسٹوریج کی تفصیل",
        "Delete Old Recordings" to "پرانی ریکارڈنگز حذف کریں", "Auto Storage Cleanup" to "خودکار صفائی", "App Settings" to "ایپ سیٹنگز", "Language" to "زبان",
        "Notifications" to "نوٹیفکیشنز", "Date & Time" to "تاریخ اور وقت", "About App" to "ایپ کے بارے میں", "Version Information" to "ورژن کی معلومات",
        "Gap Between Parts" to "حصوں کے درمیان وقفہ", "Auto Audio with Monitoring" to "مانیٹرنگ کے ساتھ خودکار آڈیو", "Allow" to "اجازت دیں", "Allowed" to "اجازت ہے", "Enable" to "فعال کریں", "Disable" to "بند کریں", "Set Password" to "پاس ورڈ لگائیں",
        "Change / Remove" to "تبدیل / ہٹائیں", "View Details" to "تفصیل دیکھیں", "Clean Now" to "ابھی صاف کریں", "Enabled" to "فعال")
    private fun tr(s: String) = if (sp.getString("lang", "en") == "ur") (UR[s] ?: s) else s
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_settings)
        findViewById<TextView>(R.id.hdrBtn).apply { text = "←"; setOnClickListener { finish() } }
        Nav.setup(this, -1)
        box = findViewById(R.id.sbox)
    }

    override fun onResume() { super.onResume(); render() }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) { super.onActivityResult(r, res, d); Monitor.onResult(this, r, res, d); render() }

    // ---------- UI helpers ----------
    private fun section(n: Int, title: String, icon: String): LinearLayout {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundResource(R.drawable.bg_row); setPadding(dp(4), dp(4), dp(4), dp(4))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) } }
        val h = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setBackgroundResource(R.drawable.bg_sect); setPadding(dp(8), dp(8), dp(14), dp(8)) }
        h.addView(TextView(this).apply { text = "$n"; gravity = Gravity.CENTER; setTextColor(0xFF111111.toInt()); setTypeface(null, 1); setBackgroundResource(R.drawable.bg_yellow_circle); layoutParams = LinearLayout.LayoutParams(dp(30), dp(30)) })
        h.addView(TextView(this).apply { text = tr(title); setTextColor(-1); textSize = 18f; setTypeface(null, 1); setPadding(dp(10), 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        h.addView(TextView(this).apply { text = icon; textSize = 20f })
        card.addView(h); box.addView(card); return card
    }

    private fun row(card: LinearLayout, icon: String, label: String, right: View?, onClick: () -> Unit) {
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(10), dp(8), dp(10)); isClickable = true; setOnClickListener { onClick() } }
        r.addView(TextView(this).apply { text = icon; textSize = 20f; gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(36), -2) })
        r.addView(TextView(this).apply { text = tr(label); textSize = 15f; setTextColor(0xFF111111.toInt()); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        if (right != null) r.addView(right)
        r.addView(TextView(this).apply { text = "›"; textSize = 24f; setTypeface(null, 1); setTextColor(0xFF1D4ED8.toInt()); setPadding(dp(8), 0, 0, 0) })
        card.addView(r)
        card.addView(View(this).apply { setBackgroundColor(0xFFE3EBF8.toInt()); layoutParams = LinearLayout.LayoutParams(-1, 1) })
    }

    private fun chip(t: String) = TextView(this).apply { text = "$t  ▾"; textSize = 13f; setTextColor(0xFF111111.toInt()); setPadding(dp(12), dp(6), dp(12), dp(6)); setBackgroundResource(R.drawable.bg_date) }
    private fun btn(t: String) = TextView(this).apply { text = tr(t); textSize = 13f; setTextColor(-1); setTypeface(null, 1); setPadding(dp(18), dp(6), dp(18), dp(6)); setBackgroundResource(R.drawable.bg_pill_on) }
    private fun pill(on: Boolean, green: Boolean = false) = TextView(this).apply {
        text = if (on) "ON  ●" else "●  OFF"; textSize = 13f; setTextColor(-1); setTypeface(null, 1); setPadding(dp(16), dp(6), dp(16), dp(6))
        setBackgroundResource(if (!on) R.drawable.bg_off else if (green) R.drawable.bg_on else R.drawable.bg_pill_on) }

    private fun choose(title: String, opts: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this).setTitle(tr(title)).setItems(opts.toTypedArray()) { _, i -> onPick(i); render() }.show()
    }
    private fun idx(vals: IntArray, key: String, def: Int) = vals.indexOf(sp.getInt(key, def)).coerceAtLeast(0)
    private fun micOk() = checkSelfPermission("android.permission.RECORD_AUDIO") == PackageManager.PERMISSION_GRANTED
    private fun usageOk(): Boolean { val o = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return o.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED }
    private fun appSettings() = startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))

    // ---------- screen ----------
    private fun render() {
        box.removeAllViews()
        findViewById<TextView>(R.id.setTitle).text = tr("Settings")
        findViewById<TextView>(R.id.setSub).text = tr("Configure Your MSF Family Monitor")
        val running = RecordService.running
        val splitV = intArrayOf(0, 5, 10, 15, 30, 60); val splitL = listOf("Continuous", "Every 5 min", "Every 10 min", "Every 15 min", "Every 30 min", "Every 60 min")
        val gapV = intArrayOf(0, 1, 2, 5); val gapL = listOf("No gap", "1 min", "2 min", "5 min")
        val qV = intArrayOf(480, 720, 1080); val qL = listOf("SD (480p)", "HD (720p)", "Full HD (1080p)")
        val aV = intArrayOf(0, 1, 2); val aL = listOf("Low", "Medium", "High")
        val cV = intArrayOf(0, 7, 15, 30); val cL = listOf("Off", "Every 7 Days", "Every 15 Days", "Every 30 Days")

        var c = section(1, "Monitoring Settings", "🔭")
        row(c, "🔘", "Monitoring ON / OFF", pill(running)) { Monitor.toggle(this); render() }
        row(c, "📷", "Screen Recording Permission", btn(if (running) "Allowed" else "Allow")) { if (!running) Monitor.request(this) else toast("Already allowed") }
        row(c, "⏱", "Auto Recording Settings", chip(splitL[idx(splitV, "rec_split", 30)])) { choose("Save a new part every… (video & audio)", splitL) { sp.edit().putInt("rec_split", splitV[it]).apply() } }
        row(c, "⏸", "Gap Between Parts", chip(gapL[idx(gapV, "rec_gap", 1)])) { choose("Pause between two parts", gapL) { sp.edit().putInt("rec_gap", gapV[it]).apply() } }
        row(c, "🎥", "Recording Quality", chip(qL[idx(qV, "rec_q", 720)])) { choose("Recording Quality", qL) { sp.edit().putInt("rec_q", qV[it]).apply() } }

        c = section(2, "Audio Settings", "🔊")
        row(c, "🎙", "Audio Recording Permission", btn(if (micOk()) "Allowed" else "Allow")) { if (!micOk()) requestPermissions(arrayOf("android.permission.RECORD_AUDIO"), 3) else appSettings() }
        val autoA = sp.getBoolean("auto_audio", false)
        row(c, "🤖", "Auto Audio with Monitoring", pill(autoA, true)) { sp.edit().putBoolean("auto_audio", !autoA).apply(); toast(if (!autoA) "Audio will start automatically with Monitoring" else "Auto audio is OFF"); render() }
        row(c, "📶", "Audio Quality", chip(aL[idx(aV, "aud_q", 2)])) { choose("Audio Quality", aL) { sp.edit().putInt("aud_q", aV[it]).apply() } }
        row(c, "🟢", "Recording Status Indicator", pill(true, true)) {
            AlertDialog.Builder(this).setMessage("The recording indicator and notification are always ON while recording. This keeps monitoring open and transparent.").setPositiveButton("OK", null).show() }

        c = section(3, "Security Settings", "🔒")
        val hasPw = sp.getString("ppw", null) != null
        row(c, "👨‍👩‍👦", "Parental Password", chip(tr(if (hasPw) "Change / Remove" else "Set Password"))) { parentalPassword() }
        row(c, "🔐", "Change PIN", chip(tr("Change PIN"))) { changePin() }
        val sec = sp.getBoolean("secure", true)
        row(c, "🖼", "Secure Gallery", btn(if (sec) "Enabled" else "Enable")) {
            if (sec) Sec.input(this, "Enter PIN to disable") { if (it == sp.getString("pin", it)) { sp.edit().putBoolean("secure", false).apply(); render() } else toast("Wrong PIN") }
            else { sp.edit().putBoolean("secure", true).apply(); Sec.gOk = false; render() } }
        row(c, "🛡", "App Permissions Details", chip(tr("View Details"))) { permissionsDialog() }

        c = section(4, "Storage Settings", "🗄")
        val files = Cleanup.dir(this).listFiles() ?: emptyArray()
        val vids = files.count { it.extension == "mp4" }
        row(c, "▶", "Saved Videos", chip("$vids Videos")) { startActivity(Intent(this, RecordingsActivity::class.java)) }
        val st = StatFs(Environment.getDataDirectory().path)
        val tot = st.blockCountLong * st.blockSizeLong; val free = st.availableBytes
        row(c, "📊", "Storage Details", chip("%.1f GB / %.0f GB".format((tot - free) / 1e9, tot / 1e9))) {
            AlertDialog.Builder(this).setTitle("Storage Details").setMessage("Recordings: %d files, %.1f MB\nFree space: %.1f GB\nTotal: %.1f GB".format(files.size, files.sumOf { it.length() } / 1048576.0, free / 1e9, tot / 1e9)).setPositiveButton("OK", null).show() }
        row(c, "🗑", "Delete Old Recordings", btn("Clean Now")) {
            val dl = listOf("Older than 7 days", "Older than 15 days", "Older than 30 days", "Delete ALL recordings"); val dv = intArrayOf(7, 15, 30, 0)
            AlertDialog.Builder(this).setTitle(tr("Delete Old Recordings")).setItems(dl.toTypedArray()) { _, i ->
                AlertDialog.Builder(this).setMessage(dl[i] + " will be deleted. Continue?").setPositiveButton("Delete") { _, _ ->
                    val n = if (dv[i] == 0) (Cleanup.dir(this).listFiles()?.count { it.delete() } ?: 0) else Cleanup.delete(this, dv[i])
                    toast("$n file(s) deleted"); render() }.setNegativeButton("Cancel", null).show() }.show() }
        row(c, "🧹", "Auto Storage Cleanup", chip(cL[idx(cV, "cleanup", 0)])) { choose("Auto Storage Cleanup", cL) { sp.edit().putInt("cleanup", cV[it]).apply(); Cleanup.run(this) } }

        c = section(5, "App Settings", "▦")
        val ur = sp.getString("lang", "en") == "ur"
        row(c, "🌐", "Language", chip(if (ur) "اردو" else "English")) { choose("Language", listOf("English", "اردو")) { sp.edit().putString("lang", if (it == 1) "ur" else "en").apply() } }
        val nOn = androidx.core.app.NotificationManagerCompat.from(this).areNotificationsEnabled()
        row(c, "🔔", "Notifications", pill(nOn)) { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)) }
        row(c, "📅", "Date & Time", chip(SimpleDateFormat("MMM dd, yyyy  hh:mm a", Locale.US).format(Date())).apply { text = SimpleDateFormat("MMM dd, yyyy  hh:mm a", Locale.US).format(Date()) }) { startActivity(Intent(Settings.ACTION_DATE_SETTINGS)) }
        val pi = packageManager.getPackageInfo(packageName, 0)
        @Suppress("DEPRECATION") val build = pi.versionCode
        row(c, "ℹ", "About App", chip("Version ${pi.versionName}").apply { text = "Version ${pi.versionName}" }) {
            AlertDialog.Builder(this).setTitle("MSF Family Monitor").setMessage("Version ${pi.versionName}\nA transparent parental-monitoring app. Recording always shows a notification on this phone.").setPositiveButton("OK", null).show() }
        row(c, "ℹ", "Version Information", chip("v${pi.versionName} (Build $build)").apply { text = "v${pi.versionName} (Build $build)" }) {
            AlertDialog.Builder(this).setTitle("Version Information").setMessage("Version: ${pi.versionName}\nBuild: $build\nPackage: $packageName\nAndroid: ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})").setPositiveButton("OK", null).show() }
    }

    private fun parentalPassword() {
        val cur = sp.getString("ppw", null)
        fun setNew() = Sec.input(this, "New password (min 4 digits, empty = remove)") { p ->
            if (p.isEmpty()) { sp.edit().remove("ppw").apply(); toast("Password removed") }
            else if (p.length >= 4) { sp.edit().putString("ppw", p).apply(); Sec.aOk = true; toast("Password set") } else toast("Min 4 digits")
            render() }
        if (cur == null) setNew() else Sec.input(this, "Current password") { if (it == cur) setNew() else toast("Wrong password") }
    }

    private fun changePin() {
        val cur = sp.getString("pin", null)
        fun setNew() = Sec.input(this, "New PIN (min 4 digits)") { p -> if (p.length >= 4) { sp.edit().putString("pin", p).apply(); toast("PIN changed") } else toast("Min 4 digits") }
        if (cur == null) setNew() else Sec.input(this, "Current PIN") { if (it == cur) setNew() else toast("Wrong PIN") }
    }

    private fun permissionsDialog() {
        fun s(b: Boolean) = if (b) "✅ Granted" else "❌ Not granted"
        val msg = "Microphone: ${s(micOk())}\nNotifications: ${s(androidx.core.app.NotificationManagerCompat.from(this).areNotificationsEnabled())}\nUsage access: ${s(usageOk())}\nScreen recording: ${if (RecordService.running) "✅ Active" else "Asked each time you start"}"
        AlertDialog.Builder(this).setTitle("App Permissions Details").setMessage(msg)
            .setPositiveButton("Open App Settings") { _, _ -> appSettings() }
            .setNeutralButton("Usage Access") { _, _ -> startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }.setNegativeButton("Close", null).show()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, g: IntArray) { super.onRequestPermissionsResult(rc, p, g); render() }
}
