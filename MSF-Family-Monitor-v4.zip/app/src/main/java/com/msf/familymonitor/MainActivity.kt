package com.msf.familymonitor

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var toggle: TextView
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        Sec.gOk = false; Sec.appGuard(this); Cleanup.run(this)
        toggle = findViewById(R.id.btnToggle); status = findViewById(R.id.tvStatus)
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS", "android.permission.RECORD_AUDIO"), 1)
        else requestPermissions(arrayOf("android.permission.RECORD_AUDIO"), 1)

        toggle.setOnClickListener { Monitor.toggle(this); refresh() }
        Nav.setup(this, 0)
        fun v(id: Int): View = findViewById(id)
        v(R.id.tRec).setOnClickListener { startActivity(Intent(this, RecordingsActivity::class.java)) }
        v(R.id.tUsage).setOnClickListener { startActivity(Intent(this, UsageActivity::class.java)) }
        v(R.id.tApps).setOnClickListener { startActivity(Intent(this, AppsActivity::class.java)) }
        v(R.id.tSet).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        v(R.id.btnGear).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        v(R.id.tLock).setOnClickListener { startActivity(Intent(this, GalleryActivity::class.java)) }
        v(R.id.tAbout).setOnClickListener {
            AlertDialog.Builder(this).setTitle("MSF Family Monitor").setMessage("Version 1.0\nA transparent parental-monitoring app. Recording always shows a notification on the child's phone.").setPositiveButton("OK", null).show()
        }
        v(R.id.navHelp).setOnClickListener {
            AlertDialog.Builder(this).setTitle("Help").setMessage("1. Tap OFF/ON to start or stop screen & audio recording.\n2. Recording is saved in parts: 30 min, then a 1 min pause, then the next part (change in Settings).\n3. Usage Report needs 'Usage access' permission (Settings).\n4. Lock Gallery is protected by your PIN. Use the green share button to send a file by Bluetooth, WhatsApp, Nearby Share, etc.").setPositiveButton("OK", null).show()
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val on = RecordService.running
        toggle.text = if (on) "●  ON" else "OFF"
        toggle.setBackgroundResource(if (on) R.drawable.bg_on else R.drawable.bg_off)
        status.text = if (on) "Monitoring Active" else "Monitoring Inactive"
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        Monitor.onResult(this, r, res, d); refresh()
    }
}
