package com.msf.familymonitor

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Dialing *#*#7273#*#* on the phone's own Dialer app fires this and reopens MSF Family Monitor,
 *  even while its launcher icon is hidden (Settings > Hide App Icon). */
class SecretCodeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "android.provider.Telephony.SECRET_CODE") return
        val open = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        context.startActivity(open)
    }
}
